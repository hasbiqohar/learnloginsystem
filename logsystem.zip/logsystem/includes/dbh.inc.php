<?php

$dbServerName = "localhost";
$dbUserName = "root";
$dbPassword = "";
$dbName = "logsystem";

$conn = mysqli_connect($dbServerName, $dbUserName, $dbPassword, $dbName);
